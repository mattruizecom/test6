import socket
import requests
import threading
import time
import tkinter as tk
from tkinter import messagebox
import urllib.request

# Function to get local and public IP addresses
def get_ip_addresses():
    local_ip = socket.gethostbyname(socket.gethostname())
    try:
        public_ip = urllib.request.urlopen('https://api.ipify.org').read().decode('utf8')
    except Exception as e:
        public_ip = "Unable to retrieve public IP"
    return local_ip, public_ip

# Constants
SERVER_URL = "http://scandalous-global-catamaran.glitch.me"  # Your Glitch URL (HTTP)
LOCAL_PORT = 25565  # Minecraft default port

# Get local IP address
LOCAL_IP, _ = get_ip_addresses()  # Initialize LOCAL_IP from the function

# Forward traffic to Minecraft server
def forward_to_minecraft(data):
    try:
        print(f"Forwarding data to Minecraft: {data.decode()}")  # Debug print for data being sent
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((LOCAL_IP, LOCAL_PORT))
            s.sendall(data)
            response = s.recv(1024)
            print(f"Received response from Minecraft server: {response.decode()}")  # Debug print for response
            return response
    except Exception as e:
        print(f"Error forwarding to Minecraft: {e}")
        return None

# Send HTTP request to the Express server
def send_http_request(data):
    try:
        response = requests.post(SERVER_URL, json={"message": data})  # Ensure the Express server is listening at this route
        if response.status_code == 200:
            print("Data sent to Express server successfully.")
            return response.json()
        else:
            print(f"Failed to send data. Status code: {response.status_code}")
            return None
    except requests.RequestException as e:
        print(f"HTTP Request failed: {e}")
        return None

# Handle incoming messages
def on_message(message):
    print(f"Message received: {message}")

    # Forward traffic to local Minecraft server
    response = forward_to_minecraft(message.encode())

    if response:
        print("Data forwarded successfully to Minecraft server.")
        send_http_request("Data forwarded successfully to Minecraft server.")
    else:
        print("Failed to forward data.")
        send_http_request("Failed to forward data.")

# Simulate receiving messages for testing
def simulate_incoming_messages():
    while True:
        message = "Test message from WebSocket"  # Simulated message
        on_message(message)
        time.sleep(5)  # Simulate delay between messages

# Function to test connection to the Glitch server
def test_connection():
    try:
        response = requests.get(f"{SERVER_URL}/secret")  # Adjust this based on your server's implementation
        if response.status_code == 200:
            secret_key = response.text  # Assuming the server sends the secret key as plain text
            messagebox.showinfo("Connection Test", f"Secret key retrieved: {secret_key}")
        else:
            messagebox.showwarning("Connection Test", "Failed to retrieve secret key.")
    except requests.RequestException as e:
        messagebox.showerror("Connection Test", f"Connection failed: {e}")

# Function to send message to Glitch server output
def submit_message():
    message = message_entry.get()  # Get the message from the input field
    if message:
        response = send_http_request(message)  # Send the message to the server
        if response:
            messagebox.showinfo("Message Sent", "Message sent to server output successfully.")
        else:
            messagebox.showerror("Send Failed", "Failed to send message to the server.")
    else:
        messagebox.showwarning("Input Error", "Please enter a message to send.")

# Function to handle port forwarding
def port_forward():
    public_ip = public_ip_entry.get()
    port = port_entry.get()
    server_name = server_name_entry.get()  # Get the server name from the input field

    payload = {
        'command': 'port_forward',
        'ip': public_ip,
        'port': port,
        'message': server_name  # Include the server name in the payload
    }

    try:
        response = requests.post(f"{SERVER_URL}/command", json=payload)  # Send port forwarding request
        if response.status_code == 200:
            messagebox.showinfo("Port Forwarding", f"Response: {response.json().get('message')}")
        else:
            messagebox.showerror("Port Forwarding Failed", "Failed to forward port.")
    except Exception as e:
        messagebox.showerror("Port Forwarding Error", f"Error: {e}")

# Function to initialize the GUI
def init_gui():
    root = tk.Tk()
    root.title("Minecraft Server Manager")

    local_ip, public_ip = get_ip_addresses()

    # Display IP addresses
    tk.Label(root, text=f"Local IP: {local_ip}").pack()
    tk.Label(root, text=f"Public IP: {public_ip}").pack()

    # Button to test connection
    test_button = tk.Button(root, text="Test if connected to Glitch server", command=test_connection)
    test_button.pack()

    # Message entry field
    global message_entry
    message_entry = tk.Entry(root, width=50)
    message_entry.pack(pady=10)

    # Submit message button
    submit_button = tk.Button(root, text="Send Message", command=submit_message)
    submit_button.pack()

    # Port forwarding section
    global public_ip_entry, port_entry, server_name_entry
    tk.Label(root, text="Public IP Address:").pack()
    public_ip_entry = tk.Entry(root, width=40)
    public_ip_entry.insert(0, public_ip)  # Autofill public IP
    public_ip_entry.pack()

    tk.Label(root, text="Port to Forward:").pack()
    port_entry = tk.Entry(root, width=10)
    port_entry.pack()

    tk.Label(root, text="Server Name:").pack()  # Label for the server name input
    server_name_entry = tk.Entry(root, width=40)  # Input field for the server name
    server_name_entry.pack()

    port_forward_button = tk.Button(root, text="Port Forward", command=port_forward)
    port_forward_button.pack()

    root.mainloop()

# Run the simulation in a separate thread
if __name__ == "__main__":
    threading.Thread(target=simulate_incoming_messages).start()
    init_gui()
